'''
Annan Fu
CS 5001, Fall 2023
Final Project -- Stock tracker
This application is a stock tracker with tailored features
based on investor type.
'''
import requests
from datetime import date, timedelta

APIKEY = 'DFYILHJL9BDQIV0S'


class Analysis():
    """
    An Analysis is a data analysis based on type with methods of:
    news and sentiment, fundamental indicators, and technical indicators.
    """
    def __init__(self, symbol):
        """
        This method is the constructor of the investor objects.
        Parameters: symbol -- string, the identifier of the stock ticker
        Return: None
        """
        self.symbol = symbol

    def fetch_news(self):
        """
        This method fetches the news dictionary and out put the list.
        Parameters: None
        Return: list, news feed list
        """
        # Determine the latest system date
        today = date.today()

        # Determine the date of the last day in API format
        one_day_from_today = today - timedelta(days=1)
        one_day_from_today_string = one_day_from_today.isoformat().replace("-", "")
        news_cutoff = one_day_from_today_string + "T0000"

        # Fetch the news dicionary of the stock
        url = f"https://www.alphavantage.co/query?function=NEWS_SENTIMENT&tickers={self.symbol}&time_from={news_cutoff}&apikey={APIKEY}"
        try:
            response = requests.get(url)
            data = response.json()
        except requests.exceptions.ConnectionError:
            return
        if response.status_code != 200:
            return

        # Return the list of news feeds
        list_news_feed = data["feed"]
        return list_news_feed

    def news_technical_analysis(self, list_news_feed):
        """
        This method counts the bullish and bearish news numbers.
        Parameters: list_news_feed -- list of news and sentiment based on user input in page
        Return: tuple of integer, the numbers of bullish and bearish news
        """
        # Initialize the count of news
        bullish_count = 0
        bearish_count = 0

        # Iterate through the list to count the news based on sentiment label
        for news in list_news_feed:
            for ticker in news["ticker_sentiment"]:
                if ticker["ticker"] == self.symbol:
                    if ticker["ticker_sentiment_label"] == "Bearish" or \
                            ticker["ticker_sentiment_label"] == "Somewhat-Bearish":
                        bearish_count += 1
                    elif ticker["ticker_sentiment_label"] == "Bullish" or \
                            ticker["ticker_sentiment_label"] == "Somewhat-Bullish":
                        bullish_count += 1

        # Return tuple of integer, the numbers of bullish and bearish news
        return bearish_count, bullish_count

    def rsi_analysis(self, investor_type):
        """
        This method returns the latest Relative Strength Index based on the investor
        type to determine the data source of daily or weekly.
        Parameters: investor_types -- string, investor type based on user input in page
        Return: string, the rsi value in string
        """
        # If technical trader, fetch daily time series of rsi
        if investor_type == "technical trader":
            url = f"https://www.alphavantage.co/query?function=RSI&symbol={self.symbol}&interval=daily&time_period=10&series_type=close&apikey={APIKEY}"

        # If average trader, fetch weekly time series of rsi
        if investor_type == "average trader":
            url = f"https://www.alphavantage.co/query?function=RSI&symbol={self.symbol}&interval=weekly&time_period=10&series_type=close&apikey={APIKEY}"
        try:
            response = requests.get(url)
            data = response.json()
        except requests.exceptions.ConnectionError:
            return
        if response.status_code != 200:
            return

        # Access the latest date and rsi value in string of the date
        date = data["Meta Data"]["3: Last Refreshed"]
        rsi_value = data["Technical Analysis: RSI"][date]["RSI"]
        return rsi_value

    def sma_analysis(self, investor_type):
        """
        This method returns the Simple Moving Average price based on the investor
        type to determine the data source of daily or weekly.
        Parameters: investor type -- string, based on user input in page
        Return: tuple of strings, the sma value 10/20/60 in string
        """
        # If technical trader, fetch daily time series of sma 10/20/60
        if investor_type == "technical trader":
            url_10_days = f"https://www.alphavantage.co/query?function=SMA&symbol={self.symbol}&interval=daily&time_period=10&series_type=close&apikey={APIKEY}"
            url_20_days = f"https://www.alphavantage.co/query?function=SMA&symbol={self.symbol}&interval=daily&time_period=20&series_type=close&apikey={APIKEY}"
            url_60_days = f"https://www.alphavantage.co/query?function=SMA&symbol={self.symbol}&interval=daily&time_period=60&series_type=close&apikey={APIKEY}"

        # If average trader, fetch weekly time series of sma 10/20/60
        if investor_type == "average trader":
            url_10_days = f"https://www.alphavantage.co/query?function=SMA&symbol={self.symbol}&interval=weekly&time_period=10&series_type=close&apikey={APIKEY}"
            url_20_days = f"https://www.alphavantage.co/query?function=SMA&symbol={self.symbol}&interval=weekly&time_period=20&series_type=close&apikey={APIKEY}"
            url_60_days = f"https://www.alphavantage.co/query?function=SMA&symbol={self.symbol}&interval=weekly&time_period=60&series_type=close&apikey={APIKEY}"
        try:
            response_10_days = requests.get(url_10_days)
            response_20_days = requests.get(url_20_days)
            response_60_days = requests.get(url_60_days)
            data_10_days = response_10_days.json()
            data_20_days = response_20_days.json()
            data_60_days = response_60_days.json()
        except requests.exceptions.ConnectionError:
            return
        if response_10_days.status_code != 200:
            return
        if response_20_days.status_code != 200:
            return
        if response_60_days.status_code != 200:
            return

        # Access the latest date and sma values in string of the date
        date = data_10_days["Meta Data"]["3: Last Refreshed"]
        sma_10_value = data_10_days["Technical Analysis: SMA"][date]["SMA"]
        sma_20_value = data_20_days["Technical Analysis: SMA"][date]["SMA"]
        sma_60_value = data_60_days["Technical Analysis: SMA"][date]["SMA"]

        # Return tuple of strings, the value of the smas
        return sma_10_value, sma_20_value, sma_60_value

    def company_overview(self):
        """
        This method returns the company financial data overview.
        Parameters: None
        Return: tuple of dictionary(the financial data dict) and string(cutoff date)
        """
        # Fetch the the company financial data overview
        url = f'https://www.alphavantage.co/query?function=OVERVIEW&symbol={self.symbol}&apikey={APIKEY}'
        try:
            response = requests.get(url)
            dict_overview = response.json()
        except requests.exceptions.ConnectionError:
            return
        if response.status_code != 200:
            return
        cut_off_date = dict_overview["LatestQuarter"]

        # Return the latest cutoff quarter end and the financial data dict
        return dict_overview, cut_off_date
