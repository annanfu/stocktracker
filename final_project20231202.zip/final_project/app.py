'''
Annan Fu
CS 5001, Fall 2023
Final Project -- Stock tracker
This application is a stock tracker with tailored features
based on inverstor type.
'''
import streamlit as st
from helpers import display_header

# Display the page header
display_header()

# Display the introduction
st.write("Stock Tracker offers a user-friendly interface for tracking stock performance in the US market. It assists investors in decision-making by tracking and monitoring the stock data from various dimensions. It provides both tailored overview based on investor types, as well as average market overview for stock comparisons.")

# Display the two main options in home page
col1, col2 = st.columns(2)

with col1:
    st.header("Investor-tailored Stock Overview")
    st.write("Tailored overview and analyses to fit your type.\nFirst, we need to know about you!")
    st.link_button("Go", "/investor_page")

with col2:
    st.header("Custom Stocks Comparison")
    st.write("Market overview, just casually pick your favourites in S&P100 and see how they performed!")
    st.link_button("Go", "/stock_comparisons")
