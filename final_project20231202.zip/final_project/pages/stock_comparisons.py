'''
Annan Fu
CS 5001, Fall 2023
Final Project -- Stock tracker
This application is a stock tracker with tailored features
based on investor type.
'''
import streamlit as st
import altair as alt
import pandas as pd
from models.investor import Investor
from models.stock import Stock
from helpers import display_header

# Display headers
display_header()
st.header("Stock Comparisons")

# A constant of list of 100 SP stocks
SP100 = [
    'AAPL', 'ABBV', 'ABT', 'ACN', 'ADBE', 'AIG', 'AMD', 'AMGN', 'AMT', 'AMZN',
    'AVGO', 'AXP', 'BA', 'BAC', 'BK', 'BKNG', 'BLK', 'BMY', 'BRK.B', 'C', 'CAT',
    'CHTR', 'CL', 'CMCSA', 'COF', 'COP', 'COST', 'CRM', 'CSCO', 'CVS', 'CVX',
    'DE', 'DHR', 'DIS', 'DOW', 'DUK', 'EMR', 'EXC', 'F', 'FDX', 'GD', 'GE',
    'GILD', 'GM', 'GOOG', 'GOOGL', 'GS', 'HD', 'HON', 'IBM', 'INTC', 'JNJ', 'JPM',
    'KHC', 'KO', 'LIN', 'LLY', 'LMT', 'LOW', 'MA', 'MCD', 'MDLZ', 'MDT', 'MET',
    'META', 'MMM', 'MO', 'MRK', 'MS', 'MSFT', 'NEE', 'NFLX', 'NKE', 'NVDA', 'ORCL',
    'PEP', 'PFE', 'PG', 'PM', 'PYPL', 'QCOM', 'RTX', 'SBUX', 'SCHW', 'SO', 'SPG',
    'T', 'TGT', 'TMO', 'TMUS', 'TSLA', 'TXN', 'UNH', 'UNP', 'UPS', 'USB', 'V', 'VZ',
    'WFC', 'WMT', 'XOM'
]

# Create an object of Investor
investor = Investor()
investor.type = "average trader"

try:
    # Get user input of no more than 5 stocks
    options = st.multiselect(
        'Choose your favourite SP100 stocks for comparison:',
        SP100)
    if len(options) > 5:
        raise ValueError

    # Fetch time series and create the price dictionary of the chosen stocks
    dictionary_price_series_of_stock = dict()
    for symbol in options:
        stock = Stock(symbol)
        stock_interval = stock.interval(investor.type)
        data = stock.fetch_time_series(stock_interval)
        list_price_series_of_stock = list(data.values())
        dictionary_price_series_of_stock[symbol] = list_price_series_of_stock

    # Display the multi-stock chart of the chosen stocks
    date_list = list(data.keys())
    df = pd.DataFrame(dictionary_price_series_of_stock, columns=options, index=pd.Index((date_list), name="Last 1 year"))
    melted_df = df.reset_index().melt("Last 1 year", var_name="Stock", value_name="Price")
    chart = alt.Chart(melted_df).mark_line().encode(
        x='Last 1 year:T',
        y=alt.Y('Price:Q', scale=alt.Scale(zero=False)),
        color='Stock:N',
    )
    st.altair_chart(chart, use_container_width=True)

except ValueError:
    st.write("You can only choose no more than 5 stocks!")
except NameError:
    st.write("Pick your stocks!")
